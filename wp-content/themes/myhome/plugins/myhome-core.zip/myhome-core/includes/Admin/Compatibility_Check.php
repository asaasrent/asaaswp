<?php

namespace MyHomeCore\Admin;


/**
 * Class Compatibility_Check
 * @package MyHomeCore\Admin
 */
class Compatibility_Check {

	public function check() {

	}

}